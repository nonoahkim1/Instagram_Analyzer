<?php

$path = "C:\Users\USER\Documents\MAMP\webdev\macro_assignment\macro_assignment_08\databases";
$db = new SQLite3($path.'/discussion.db');

 ?>
